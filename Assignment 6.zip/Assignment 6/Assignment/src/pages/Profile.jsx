import React, { useState } from 'react';
function Profile() 
{
  const [show, setShow] = useState(false)
const toggleDetails = () => {
    setShow(!show)
  }
return (
    <div className="container">
      <h2>Conditional Rendering Example</h2>
      <button onClick={toggleDetails}>
        {show ? 'Hide' : 'Show'} Details
      </button>
      {show && <p>This is the react project I had created using React Router DOM, useEffect and Conditional Rendering .</p>}
    </div>
  )
}
export default Profile;
