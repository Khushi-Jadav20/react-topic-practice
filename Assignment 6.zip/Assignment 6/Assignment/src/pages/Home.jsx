import React, { useState, useEffect } from 'react';
function Home() {
  const [count, setCount] = useState(0)
useEffect(() => {
    alert("Welcome! Click the button to increase the count.")
  }, [])

  useEffect(() => {
    console.log("Count is: ", count)
  }, [count])
return (
    <div className="container">
      <h2>useEffect Example</h2>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increase</button>
    </div>
  )
}
export default Home;
